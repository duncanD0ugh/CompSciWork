<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
    href=https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css >
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style>
        .page-style{
            margin: 20px;
        }
    </style>
    <title>Create Account</title>
</head>

<body>
    <div class="page-style">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="../index.php">Implementation Selection Page</a>
            <a class="navbar-brand" href="index.php">Register</a>
            <a class="navbar-brand" href="login.php">Login</a>
        </nav>
        <h1>Create Account</h1>
    </div>
    <div class="page-style">
        <form action="index.php" method="post">
            <div class="form-group">
                <label for="fname">First Name</label>
                <input type="text" class="form-control" name="fname">
            </div>
            <div class="form-group">
                <label for="lname">Last Name</label>
                <input type="text" class="form-control" name="lname">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password">
            </div>
            <div class="form-group">
                <label for="password">Confirm Password</label>
                <input type="password" class="form-control" name="cpassword">
            </div>
            <button type="submit" class="btn btn-primary">Create Account</button>
        </form>

        <!-- PHP codes to check for entered information for account registration -->
        <?php
            $fname = "";
            $lname = "";
            $email = "";
            $password = "";
            $cpassword = "";

            if (isset($_POST["fname"]) && isset($_POST["lname"])
                && isset($_POST["email"]) && isset($_POST["password"])
                && isset($_POST["cpassword"])) {
                $fname = $_POST["fname"];
                $lname = $_POST["lname"];
                $email = $_POST["email"];
                $password = $_POST["password"];
                $cpassword = $_POST["cpassword"];

                // same simple validation for user inputs, not checking for any attacks
                if (!$fname || !$lname || !$email || !$password || !$cpassword) {
                    echo "<p>Please complete the form to create account!</p>";
                    exit;
                }

                if ($password != $cpassword) {
                    echo "<p>Please make sure Password and Confirm Password are matched!</p>";
                    exit;
                }

                require_once "db_config.php";

                // check if email already exist, email is used for primary key
                $checkSql = "SELECT * FROM user_s3847428 WHERE email = '$email'";
                $checkResult = mysqli_query($connection, $checkSql);
                $checkRow = mysqli_num_rows($checkResult);

                if ($checkResult && $checkRow > 0) {
                    echo "<p>Email entered is already registered!</p>";
                    exit;
                }

                // insert data into table
                $insertSql = "INSERT INTO user_s3847428(email, password, fname, lname) VALUES ('$email', '$password', '$fname', '$lname')";
                $result = mysqli_query($connection, $insertSql);

                // check if insert query is successful
                if ($result) {
                    // redirect page to login page
                    header("Location: login.php");
                }
                else {
                    // error message, stay on index page, create account
                    echo "<p>Something went wrong!</p>";
                    exit;
                }

                // free query results and close connection
                mysqli_free_result($checkResult);
                mysqli_free_result($result);
                mysqli_close($connection);
            }
            else {
                echo "Please complete the form for registration.";
            }
        ?>
    </div>
</body>
</html>
