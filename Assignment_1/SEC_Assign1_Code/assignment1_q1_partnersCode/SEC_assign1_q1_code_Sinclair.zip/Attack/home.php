<?php
    session_start();

    // Check if the user is logged in, if not then redirect him to login page (login.html)
    // not implemented in order to perform Force Browsing on the website
//    if  (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
//        header("Location: login.php");
//        exit;
//    }

    $fname = "";
    $lname = "";

    // get session variables on first name and last name, assign to php variables for displaying
    $fname = $_SESSION["fname"];
    $lname = $_SESSION["lname"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
    href=https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css >
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        .page-style{
            margin: 20px;
        }
    </style>
    <title>Home Page</title>
</head>

<body>
    <div class="page-style"><h1>Welcome to Alice E-Commerce Website!</h1></div>
    <div class="page-style">

        <div class="page-header">
            <?php
                echo "<p>Hi, $fname $lname!</p>";
            ?>
        </div>

        <p><a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a></p>
    </div>
</body>
</html>
