<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
    href=https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css >
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style>
        .page-style{
            margin: 20px;
        }
    </style>
    <title>Login</title>
</head>

<body>
    <div class="page-style">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="../index.php">Implementation Selection Page</a>
            <a class="navbar-brand" href="index.php">Register</a>
            <a class="navbar-brand" href="login.php">Login</a>
        </nav>
        <h1>Login Account</h1>
    </div>
    <div class="page-style">
        <form action="login.php" method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>

        <?php
            $fname = "";
            $lname = "";
            $email = "";
            $password = "";

            if (isset($_POST["email"]) && isset($_POST["password"])) {
                $email = $_POST["email"];
                $password = $_POST["password"];

                require_once "db_config.php";

                $sql = "SELECT * FROM user_s3847428 WHERE email = '$email' AND password = '$password'";
                $result = mysqli_query($connection, $sql);
                $row = mysqli_num_rows($result);

                if ($result && $row > 0) {
                    $data = mysqli_fetch_assoc($result);
                    // get first name and last name of the account login to session variables
                    $_SESSION["fname"] = $data["fname"];
                    $_SESSION["lname"] = $data["lname"];

                    // login information
//                    $_SESSION["loggedin"] = true;

                    // redirect page to home page
                    header("Location: home.php");
                }
                else {
                    echo "<p>Login Failed! Please check your credentials!</p>";
                }

                // free query result and close connection
                mysqli_free_result($result);
                mysqli_close($connection);
            }
        ?>
    </div>
</body>
</html>
