<?php
  // Functions to open and close Database

  // Function to open database connection, returns the mysqli object that connects to DB
  // Reads the connection information for the database from dbconfig.ini
  function DBConn() {

    $dbconfig = parse_ini_file("dbconfig.ini");
    $dbhost = $dbconfig["host"];
    $dbuser = $dbconfig["user"];
    $dbpass = $dbconfig["pass"];
    $dbname = $dbconfig["name"];
    $dbport = $dbconfig["port"];

    $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname, $dbport) or die("Connect failed: %s\n". $conn -> error);
 
    return $conn;
  }
 
  // Function to close the database connection
  function CloseCon($conn)
  {
    $conn -> close();
  }
   
?>