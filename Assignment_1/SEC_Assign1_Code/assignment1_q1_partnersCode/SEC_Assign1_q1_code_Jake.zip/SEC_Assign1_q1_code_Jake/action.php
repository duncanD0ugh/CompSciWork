<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Extracting Info using SQL Injection</title>
 
 </head>
 <body style="margin-top: 50px">
 <div class="container">
 <div class="row">
 <div class="span6">


 <?php 

 include 'dbconnection.php';
 $conn = DBConn();
$email = $_POST['email'];
$password = $_POST['password'];
$sqli = "SELECT * FROM `users` WHERE Email = '$email'
and password = '$password' ";
$result = mysqli_query($conn,$sqli);
   if(mysqli_num_rows($result)>0)
{
     echo "<h1>You Have Successfuly signed in</h1>";
     echo "<h4>"."-- Personal Information -- </h4>",
"</br>";
while ($row=mysqli_fetch_row($result)){
     echo "<p>"."Username : ".$row[0]."</p>";
     echo "<p>"."Password : ".$row[1]."</p>";
     echo "<p>"."First Name : ".$row[2]."</p>";
     echo "<p>"."Last Name : ".$row[3]."</p>";
     echo "<p>"."Email : ".$row[4]."</p>";
     

     echo "--------------------------------------------";}} 
     else echo "Invalid user id or password";
     
     ?>
</div>
</div>
</div>
</body>
</html>